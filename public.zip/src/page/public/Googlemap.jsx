import React from 'react'
import Map from "../../components/Map";

function Googlemap() {
  return (
      <>
      <Map/>
      
      </>
  )
}

export default Googlemap