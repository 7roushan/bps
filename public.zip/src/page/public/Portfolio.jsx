// import React from "react";
// import Slider from "react-slick";
// import "slick-carousel/slick/slick.css";
// import "slick-carousel/slick/slick-theme.css";

// const Portfolio = () => {
//   const portfolioItems = [
//     {
//       id: 155,
//       category: "development-sort",
//       image:
//         "https://dtlogistics.wpenginepowered.com/wp-content/uploads/2014/01/portfolio1.jpg",
//       title: "Cras tristique purus non lacus",
//       link: "https://dtlogistics.wpengine.com/dt_portfolios/cras-tristique-purus-non-lacus/",
//     },
//     {
//       id: 154,
//       category: "development-sort",
//       image:
//         "https://dtlogistics.wpenginepowered.com/wp-content/uploads/2014/01/portfolio2.jpg",
//       title: "Duis fermentum felis",
//       link: "https://dtlogistics.wpengine.com/dt_portfolios/duis-fermentum-felis/",
//     },
//     {
//       id: 153,
//       category: "web-design-sort",
//       image:
//         "https://dtlogistics.wpenginepowered.com/wp-content/uploads/2014/01/portfolio3.jpg",
//       title: "Quisque id maximus leo",
//       link: "https://dtlogistics.wpengine.com/dt_portfolios/quisque-id-maximus-leo/",
//     },
//     {
//       id: 152,
//       category: "web-design-sort",
//       image:
//         "https://dtlogistics.wpenginepowered.com/wp-content/uploads/2014/01/portfolio4.jpg",
//       title: "Aenean facilisis tortor",
//       link: "https://dtlogistics.wpengine.com/dt_portfolios/aenean-facilisis-tortor/",
//     },
//   ];

//   const settings = {
//     dots: true,
//     infinite: true,
//     speed: 500,
//     slidesToShow: 3, // Show 3 images at a time
//     slidesToScroll: 1,
//     autoplay: true,
//     autoplaySpeed: 2000,
//     arrows: true,
//     centerMode: false,
//     responsive: [
//       {
//         breakpoint: 1024,
//         settings: {
//           slidesToShow: 2, // Show 2 images on medium screens
//         },
//       },
//       {
//         breakpoint: 768,
//         settings: {
//           slidesToShow: 1, // Show 1 image on small screens
//         },
//       },
//     ],
//   };

//   return (
//     <div id="main" style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
//       {/* Header Section */}
//       <section
//         style={{
          
//           padding: "20px 0",
//           display: "flex",
//           flexDirection: "column",
//           alignItems: "center",
//           textAlign: "center",
//         }}
//       >
//         <h1 style={{ margin: "0 0 10px", fontSize: "32px", color: "#333" }}>
//          PORTFOLIO
//         </h1>
//         <div style={{ marginTop: "10px" }}>
//           <a href="/" style={{ textDecoration: "none", color: "#007bff" }}>
//             Home
//           </a>
//           <span> / </span>
//           <span style={{ color: "#666" }}>Portfolio</span>
//         </div>
//       </section>

//       {/* Slider Section */}
//       <div style={{ maxWidth: "1200px", margin: "30px auto", padding: "0 20px" }}>
//         <Slider {...settings}>
//           {portfolioItems.map((item) => (
//             <div key={item.id} style={{ padding: "10px" }}>
//               <div
//                 style={{
//                   boxShadow: "0px 4px 10px rgba(0,0,0,0.15)",
//                   borderRadius: "10px",
//                   overflow: "hidden",
//                   margin: "0 10px",
//                   transition: "transform 0.3s ease",
//                 }}
//               >
//                 <figure style={{ margin: 0 }}>
//                   <img
//                     src={item.image}
//                     alt={item.title}
//                     title={item.title}
//                     style={{
//                       width: "100%",
//                       height: "250px",
//                       objectFit: "cover",
//                       borderRadius: "10px 10px 0 0",
//                     }}
//                   />
//                   <div
//                     style={{
//                       padding: "15px",
//                       backgroundColor: "#fff",
//                       textAlign: "center",
//                     }}
//                   >
//                     <a
//                       href={item.link}
//                       style={{
//                         textDecoration: "none",
//                         color: "#007bff",
//                         fontWeight: "bold",
//                         fontSize: "16px",
//                         display: "block",
//                       }}
//                     >
//                       {item.title}
//                     </a>
//                   </div>
//                 </figure>
//               </div>
//             </div>
//           ))}
//         </Slider>
//       </div>
//     </div>
//   );
// };
// export default Portfolio;

import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const Portfolio = () => {
  const portfolioItems = [
    {
      id: 155,
      category: "development-sort",
      image:
        "https://dtlogistics.wpenginepowered.com/wp-content/uploads/2014/01/portfolio1.jpg",
      title: "Experienced driver",
      link: "https://dtlogistics.wpengine.com/dt_portfolios/cras-tristique-purus-non-lacus/",
    },
    {
      id: 154,
      category: "development-sort",
      image: "https://pierbridge.com/media/iz0nchdj/top-10-things-to-consider_002.png",
      title: "Integration of API",
      link: "https://dtlogistics.wpengine.com/dt_portfolios/duis-fermentum-felis/",
    },

    {
      id: 153,
      category: "web-design-sort",
      image:
        "https://dtlogistics.wpenginepowered.com/wp-content/uploads/2014/01/portfolio3.jpg",
      title: "Quick Delivery",
      link: "https://dtlogistics.wpengine.com/dt_portfolios/quisque-id-maximus-leo/",
    },
    {
      id: 152,
      category: "web-design-sort",
      image:
        "https://dtlogistics.wpenginepowered.com/wp-content/uploads/2014/01/portfolio4.jpg",
      title: "Outstanding service",
      link: "https://dtlogistics.wpengine.com/dt_portfolios/aenean-facilisis-tortor/",
    },
  ];

  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 3, // Show 3 images at a time
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 2000,
    arrows: true,
    centerMode: false,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 2, // Show 2 images on medium screens
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 1, // Show 1 image on small screens
        },
      },
    ],
  };

  return (
    <div id="main" style={{ fontFamily: "Arial, sans-serif", padding: "20px" }}>
      {/* Header Section */}
      {/* <section
        style={{
          
          padding: "20px 0",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          textAlign: "center",
        }}
      >
        <h1 style={{ margin: "0 0 10px", fontSize: "32px", color: "#333" }}>
        Why choose Bharat Parcel Services?
        </h1>
        <div style={{ marginTop: "10px" }}>
          <a style={{ textDecoration: "none", color: "#007bff" }}>
          Your Prime Choice for Reliable and Efficient Parcel Delivery Solutions.
          </a>
        

        </div>
      </section> */}

<section style={{ 
  padding: "60px 0",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  textAlign: "center",
  background: "linear-gradient(145deg, #ffffff 0%, #f8f9fa 100%)",
  position: "relative",
  overflow: "hidden",
  transition: "all 0.3s ease",
  cursor: "pointer",
  borderRadius: "15px",
  margin: "20px",
  boxShadow: "0 10px 30px rgba(0,0,0,0.05)",
  ":hover": {
    transform: "translateY(-5px)",
    boxShadow: "0 15px 40px rgba(0,0,0,0.1)"
  }
}}>
  <h3 style={{ 
    margin: "0 0 15px",
    fontSize: "2.8rem",
    color: "#2d3436",
    fontWeight: "700",
    letterSpacing: "-0.5px",
    position: "relative",
    animation: "fadeInUp 0.8s ease",
    textTransform: "uppercase",
    background: "linear-gradient(45deg, #2d3436, #007bff)",
    WebkitBackgroundClip: "text",
    WebkitTextFillColor: "transparent"
  }}>
    Why choose Bharat Parcel Services?
  </h3>

  <div style={{ 
    marginTop: "20px",
    position: "relative",
    maxWidth: "800px",
    padding: "0 20px"
  }}>
    <div style={{
      position: "relative",
      display: "inline-block",
      transition: "all 0.3s ease",
      ":hover": {
        transform: "scale(1.02)"
      }
    }}>
      <div style={{
        fontSize: "1.2rem",
        color: "#4a4a4a",
        lineHeight: "1.6",
        fontWeight: "500",
        position: "relative",
        padding: "15px 30px",
        borderRadius: "50px",
        background: "rgba(0,123,255,0.1)",
        transition: "all 0.3s ease",
        ":hover": {
          background: "rgba(0,123,255,0.15)",
          boxShadow: "0 5px 15px rgba(0,123,255,0.1)"
        }
      }}>
        Your Prime Choice for Reliable and Efficient Parcel Delivery Solutions.
      </div>
      <div style={{
        position: "absolute",
        bottom: "-5px",
        left: "50%",
        transform: "translateX(-50%)",
        width: "60%",
        height: "2px",
        background: "linear-gradient(90deg, transparent, #007bff, transparent)",
        opacity: "0.5",
        transition: "all 0.3s ease"
      }} />
    </div>
  </div>

  {/* Add some animated decorative elements */}
  <div style={{
    position: "absolute",
    top: "-50px",
    right: "-50px",
    width: "150px",
    height: "150px",
    background: "rgba(0,123,255,0.05)",
    borderRadius: "50%",
    animation: "float 6s ease-in-out infinite"
  }} />
  <div style={{
    position: "absolute",
    bottom: "-30px",
    left: "-30px",
    width: "100px",
    height: "100px",
    background: "rgba(0,123,255,0.05)",
    borderRadius: "30%",
    transform: "rotate(45deg)",
    animation: "float 4s ease-in-out infinite"
  }} />
</section>

      {/* Slider Section */}
      <div style={{ maxWidth: "1150px", margin: "30px auto", padding: "0 20px" }}>
        <Slider {...settings}>
          {portfolioItems.map((item) => (
            <div key={item.id} style={{ padding: "10px" }}>
              <div
                style={{
                  boxShadow: "0px 4px 10px rgba(0,0,0,0.15)",
                  borderRadius: "10px",
                  overflow: "hidden",
                  margin: "0 10px",
                  transition: "transform 0.3s ease",
                }}
              >
                <figure style={{ margin: 0 }}>
                  <img
                    src={item.image}
                    alt={item.title}
                    title={item.title}
                    style={{
                      width: "100%",
                      height: "250px",
                      objectFit: "cover",
                      borderRadius: "10px 10px 0 0",
                    }}
                  />
                  <div
                    style={{
                      padding: "15px",
                      backgroundColor: "#fff",
                      textAlign: "center",
                    }}
                  >
                    <a
                      href={item.link}
                      style={{
                        textDecoration: "none",
                        color: "#007bff",
                        fontWeight: "bold",
                        fontSize: "16px",
                        display: "block",
                      }}
                    >
                      {item.title}
                    </a>
                  </div>
                </figure>
              </div>
            </div>
          ))}
        </Slider>
      </div>
    </div>
  );
};

export default Portfolio;
