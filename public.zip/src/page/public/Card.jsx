// import React from "react";
// import { Myservices1 } from "../../data/Myservices";
// import { useNavigate } from "react-router-dom";
// import { CardContent, Grid, Typography, Card as MuiCard, Container } from "@mui/material";

// const Card = () => {
//   const navigate = useNavigate();

//   const handleCardClick = (serviceId) => {
//     navigate(`/services/${serviceId}`);
//   };

//   return (
//     <div>
//         <Container>
//       <Grid item xs={12} md={8}>
//         <Grid container spacing={2}>
//           {Myservices1.map((service, index) => (
//             <Grid item xs={12} sm={6} md={4} key={index}>
//               <MuiCard
//                 sx={{
//                   boxShadow: 2,
//                   cursor: "pointer",
//                   height: "420px",
//                   borderRadius: "0px",
//                 }}
//                 onClick={() => handleCardClick(service.id)}
//               >
//                 <img
//                   src={service.imgpath}
//                   alt={service.title}
//                   style={{ width: "100%", height: 240, objectFit: "cover" }}
//                 />
//                 <CardContent>
//                   <Typography
//                     variant="h6"
//                     fontWeight="bold"
//                     sx={{ color: "#002b5b" }}
//                   >
//                     {service.title}
//                   </Typography>
//                   <Typography variant="body2" color="text.secondary">
//                     {service.desc}
//                   </Typography>
//                   <Typography
//                     variant="body2"
//                     sx={{
//                       mt: 1,
//                       color: "#002b5b",
//                       fontWeight: "bold",
//                       cursor: "pointer",
//                     }}
//                   >
//                     read more &gt;
//                   </Typography>
//                 </CardContent>
//               </MuiCard>
//             </Grid>
//           ))}
//         </Grid>
//       </Grid>
//       </Container>
//     </div>
//   );
// };

// export default Card;


import React from "react";
import { Myservices1 } from "../../data/Myservices";
import { useNavigate } from "react-router-dom";
import { CardContent, Grid, Typography, Card as MuiCard, Container, Box } from "@mui/material";

const Card = () => {
  const navigate = useNavigate();

  const handleCardClick = (serviceId) => {
    navigate(`/services/${serviceId}`);
  };

  return (
    <Box>
    <Typography fontWeight={800} textAlign="center" variant="h1"> The BPS delivery service</Typography>
    <Box maxWidth="lg" sx={{  py:5, mx: "auto" }}>

      <Grid container spacing={3} justifyContent="center">

        {Myservices1.map((service, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <MuiCard
              sx={{
                boxShadow: 2,
                cursor: "pointer",
                height: { xs: "auto", md: "420px" }, // Auto height on mobile
                borderRadius: "8px",
                transition: "transform 0.2s",
                "&:hover": { transform: "scale(1.05)" }, // Slight hover effect
              }}
              onClick={() => handleCardClick(service.id)}
            >
              <img
                src={service.imgpath}
                alt={service.title}
                style={{
                  width: "100%",
                  height: "240px",
                  objectFit: "cover",
                }}
              />
              <CardContent>
                <Typography
                  variant="h6"
                  fontWeight="bold"
                  sx={{ color: "#002b5b" }}
                >
                  {service.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {service.desc}
                </Typography>
                <Typography
                  variant="body2"
                  sx={{
                    mt: 1,
                    color: "#002b5b",
                    fontWeight: "bold",
                    cursor: "pointer",
                  }}
                >
                  read more &gt;
                </Typography>
              </CardContent>
            </MuiCard>
          </Grid>
        ))}
      </Grid>
    </Box> 
    </Box>
  );
};

export default Card;

