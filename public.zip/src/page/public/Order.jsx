// import React, { useState } from "react";
// import {
//   Button,
//   TextField,
//   Select,
//   MenuItem,
//   InputLabel,
//   FormControl,
//   Grid,
//   Typography,
//   Paper,
//   Container,
//   IconButton,
//   Box,
//   Breadcrumbs,
// } from "@mui/material";
// import {
//   AddCircleOutline,
//   RemoveCircleOutline,
//   Send,
//   LocationOn,
//   Person,
//   LocalShipping,
//   AttachMoney,
// } from "@mui/icons-material";
// import { styled } from "@mui/material/styles";
// import contactBanner from "../../assets/images/contact.jpg";
// import { Link } from "react-router-dom";

// const StyledPaper = styled(Paper)(({ theme }) => ({
//   padding: theme.spacing(4),
//   borderRadius: theme.spacing(3),
//   background: "linear-gradient(145deg, #f8faff, #ffffff)",
//   boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)",
//   position: "relative",
//   overflow: "hidden",
//   "&:before": {
//     content: '""',
//     position: "absolute",
//     top: 0,
//     left: 0,
//     width: "4px",
//     height: "100%",
//     background: theme.palette.primary.main,
//   },
// }));

// const SectionTitle = styled(Typography)(({ theme }) => ({
//   marginBottom: theme.spacing(3),
//   color: theme.palette.primary.dark,
//   fontWeight: 700,
//   display: "flex",
//   alignItems: "center",
//   gap: theme.spacing(1),
//   "& svg": {
//     fontSize: "1.5rem",
//   },
// }));

// const StyledButton = styled(Button)(({ theme }) => ({
//   borderRadius: theme.spacing(2),
//   padding: theme.spacing(2),
//   fontSize: "1.1rem",
//   transition: "all 0.3s ease",
//   background: "linear-gradient(45deg, #1976d2, #2196f3)",
//   "&:hover": {
//     transform: "translateY(-2px)",
//     boxShadow: "0 4px 15px rgba(25, 118, 210, 0.4)",
//   },
// }));

// const ProductBox = styled(Box)(({ theme }) => ({
//   marginBottom: theme.spacing(2),
//   padding: theme.spacing(3),
//   background: "#f8faff",
//   borderRadius: theme.spacing(2),
//   border: `1px solid ${theme.palette.primary.light}`,
//   position: "relative",
// }));

// const Order = () => {
//   // ... existing state and handlers remain the same ...

//   const handleSubmit = (event) => {
//     event.preventDefault();
//     console.log("Form submitted!");
//     // Add your form submission logic here (e.g., API call)
//   };

//   const [stations] = useState(["Station A", "Station B", "Station C"]);
//   const [products, setProducts] = useState([{ id: 1 }]);

//   const handleInputChange = (event) => {
//     console.log(event.target.name, event.target.value);
//   };

//   const addProduct = () => {
//     setProducts([...products, { id: products.length + 1 }]);
//   };

//   const removeProduct = (id) => {
//     setProducts(products.filter((product) => product.id !== id));
//   };

//   return (
//     <>     <Box
//     sx={{
//       position: "relative",
//       width: "100vw",
//       height: { xs: "300px", md: "350px" },
//       backgroundImage: `url(${contactBanner})`,
//       backgroundSize: "cover",
//       backgroundPosition: "center",
//       display: "flex",
//       alignItems: "center",
//       "&:after": {
//         content: '""',
//         position: "absolute",
//         top: 0,
//         left: 0,
//         right: 0,
//         bottom: 0,
//         background: "rgba(0, 0, 0, 0.6)",
//       },
//     }}
//   >
//     <Container sx={{ position: "relative", zIndex: 1 }}>
//       <Breadcrumbs sx={{ color: "white", mb: 2 }}>

//       </Breadcrumbs>
//       <Typography
//         variant="h2"
//         sx={{
//           color: "white",
//           fontWeight: 800,
//           fontSize: { xs: "2rem", sm: "3rem", md: "4rem" },
//           textShadow: "2px 2px 8px rgba(0,0,0,0.7)",
//         }}
//       >
//         Make Your Booking
//       </Typography>

//     </Container>
//   </Box>

//     <Container maxWidth="lg" sx={{ backgroundcolour :"blue", my: 4, py: 6 }}>

//       <StyledPaper  >
//         <Typography
//           variant="h4"
//           align="center"
//           gutterBottom
//           sx={{
//             color: "primary.main",
//             fontWeight: 800,
//             mb: 6,
//             textTransform: "uppercase",
//             letterSpacing: 1.2,
//           }}
//         >
//           <LocalShipping
//             sx={{ fontSize: "2.5rem", mr: 1.5, verticalAlign: "middle" }}
//           />
//           Create Your Booking
//         </Typography>

//         <form onSubmit={handleSubmit}>
//           <Grid container spacing={2}>
//             {/* Station Details */}
//             <Grid item xs={12}>
//               <SectionTitle variant="h6">
//                 <LocationOn />
//                 Station Information
//               </SectionTitle>
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <FormControl fullWidth variant="outlined">
//                 <InputLabel>Start Station</InputLabel>
//                 <Select
//                   label="Start Station"
//                   name="startStation"
//                   onChange={handleInputChange}
//                   sx={{ borderRadius: 2 }}
//                 >
//                   {stations.map((station) => (
//                     <MenuItem key={station} value={station}>
//                       {station}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <FormControl fullWidth variant="outlined">
//                 <InputLabel>Destination Station</InputLabel>
//                 <Select
//                   label="Destination Station"
//                   name="destinationStation"
//                   onChange={handleInputChange}
//                   sx={{ borderRadius: 2 }}
//                 >
//                   {stations.map((station) => (
//                     <MenuItem key={station} value={station}>
//                       {station}
//                     </MenuItem>
//                   ))}
//                 </Select>
//               </FormControl>
//             </Grid>

//             {/* Date Fields */}
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 type="date"
//                 label="Booking Date"
//                 name="bookingDate"
//                 onChange={handleInputChange}
//                 InputLabelProps={{ shrink: true }}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 type="date"
//                 label="Delivery Date"
//                 name="deliveryDate"
//                 onChange={handleInputChange}
//                 InputLabelProps={{ shrink: true }}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>

//             {/* Customer Details */}
//             <Grid item xs={12}>
//               <SectionTitle variant="h6">
//                 <Person />
//                 Customer Information
//               </SectionTitle>
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="First Name"
//                 name="firstName"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Middle Name"
//                 name="middleName"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Last Name"
//                 name="lastName"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Contact Number "
//                 name="Contact Number"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Email Address"
//                 name="Email"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>

//             {/* From Address */}
//             <Grid item xs={12}>
//               <SectionTitle variant="h6">From Address</SectionTitle>
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="First Name"
//                 name="firstName"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="GST No."
//                 name="mGST No."
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Locality/street"
//                 name="Locality/Street"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="State"
//                 name="State"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="City"
//                 name="City"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Pin Code"
//                 name="Pin Code"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>

//             {/* From Address */}
//             <Grid item xs={12}>
//               <SectionTitle variant="h6">To Address</SectionTitle>
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="First Name"
//                 name="firstName"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="GST No."
//                 name="mGST No."
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Locality/street"
//                 name="Locality/Street"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="State"
//                 name="State"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="City"
//                 name="City"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={4}>
//               <TextField
//                 fullWidth
//                 label="Pin Code"
//                 name="Pin Code"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>

//             {/* Product Details */}
//             <Grid item xs={12}>
//               <SectionTitle variant="h6">
//                 <LocalShipping />
//                 Product Details
//               </SectionTitle>
//               {products.map((product, index) => (
//                 <ProductBox key={product.id}>
//                   <Grid container spacing={3} alignItems="center">
//                     <Grid
//                       item
//                       xs={12}
//                       container
//                       justifyContent="space-between"
//                       alignItems="center"
//                     >
//                       <Typography
//                         variant="subtitle1"
//                         color="primary"
//                         sx={{ fontWeight: 600 }}
//                       >
//                         Product #{index + 1}
//                       </Typography>
//                       <IconButton
//                         onClick={() => removeProduct(product.id)}
//                         disabled={products.length === 1}
//                         sx={{
//                           color:
//                             products.length === 1
//                               ? "text.disabled"
//                               : "error.main",
//                         }}
//                       >
//                         <RemoveCircleOutline />
//                       </IconButton>
//                     </Grid>

//                     <Grid item xs={12} sm={6} md={3}>
//                       <TextField
//                         fullWidth
//                         label="Receipt No."
//                         name={`receiptNo_${product.id}`}
//                         onChange={handleInputChange}
//                         variant="outlined"
//                         sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//                       />
//                     </Grid>
//                     <Grid item xs={12} sm={6} md={3}>
//                       <TextField
//                         fullWidth
//                         label="Reference No."
//                         name={`refNo_${product.id}`}
//                         onChange={handleInputChange}
//                         variant="outlined"
//                         sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//                       />
//                     </Grid>
//                     <Grid item xs={12} sm={6} md={3}>
//                       <TextField
//                         fullWidth
//                         label="Insurance"
//                         name={`insurance_${product.id}`}
//                         onChange={handleInputChange}
//                         variant="outlined"
//                         sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//                       />
//                     </Grid>
//                     <Grid item xs={12} sm={6} md={3}>
//                       <FormControl fullWidth variant="outlined">
//                         <InputLabel>Payment</InputLabel>
//                         <Select
//                           label="Payment"
//                           name={`payment_${product.id}`}
//                           onChange={handleInputChange}
//                           sx={{ borderRadius: 2 }}
//                         >
//                           <MenuItem value="To Pay">To Pay</MenuItem>
//                           <MenuItem value="Paid">Paid</MenuItem>
//                         </Select>
//                       </FormControl>
//                     </Grid>
//                     <Grid item xs={12} sm={4}>
//                       <TextField
//                         fullWidth
//                         label="VVP Amount"
//                         name="VVP Amount"
//                         onChange={handleInputChange}
//                         variant="outlined"
//                         sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//                       />
//                     </Grid>
//                     <Grid item xs={12} sm={4}>
//                       <TextField
//                         fullWidth
//                         label="Weight Kgs."
//                         name="Weight Kgs."
//                         onChange={handleInputChange}
//                         variant="outlined"
//                         sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//                       />
//                     </Grid>
//                     <Grid item xs={12} sm={4}>
//                       <TextField
//                         fullWidth
//                         label="Amount"
//                         name="Amount"
//                         onChange={handleInputChange}
//                         variant="outlined"
//                         sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//                       />
//                     </Grid>
//                   </Grid>
//                 </ProductBox>
//               ))}
//               <Button
//                 variant="outlined"
//                 startIcon={<AddCircleOutline />}
//                 onClick={addProduct}
//                 sx={{
//                   mt: 2,
//                   borderRadius: 2,
//                   borderWidth: 2,
//                   "&:hover": { borderWidth: 2 },
//                 }}
//               >
//                 Add Product
//               </Button>
//             </Grid>

//             {/* From Address */}

//             <Grid item xs={12} sm={12}>
//               <TextField
//                 fullWidth
//                 multiline
//                 rows={4} // Adjust the number of rows for desired height
//                 label="Additional Comments"
//                 name="additionalComments"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{
//                   "& .MuiOutlinedInput-root": { borderRadius: 2 },
//                 }}
//               />
//             </Grid>

//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="FREIGHT"
//                 name="FREIGHT"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="INS/VPP"
//                 name="INS/VPP"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="Bill Total"
//                 name="Bill Total"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="CGST%"
//                 name="CGST%"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="SGST%"
//                 name="SGST%"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="SGST%"
//                 name="SGST%"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="IGST%"
//                 name="IGST%"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>
//             <Grid item xs={12} sm={6}>
//               <TextField
//                 fullWidth
//                 label="Grand Total"
//                 name="Grand Total"
//                 onChange={handleInputChange}
//                 variant="outlined"
//                 sx={{ "& .MuiOutlinedInput-root": { borderRadius: 2 } }}
//               />
//             </Grid>

//             {/* Billing Section */}

//             {/* Submit Button */}
//             <Grid item xs={12} sx={{ textAlign: "center" }}>
//               <StyledButton
//                 type="submit"
//                 variant="contained"
//                 size="large"
//                 startIcon={<Send sx={{ fontSize: "1rem" }} />}
//                 justifycontent="center"
//               >
//                 Confirm Booking
//               </StyledButton>
//             </Grid>
//           </Grid>
//         </form>
//       </StyledPaper>
//     </Container>
//     </>
//   );
// };

// export default Order;

import React, { useState } from "react";
import {
  Button,
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Grid,
  Typography,
  Paper,
  Container,
  IconButton,
  Box,
  Breadcrumbs,
} from "@mui/material";
import {
  AddCircleOutline,
  RemoveCircleOutline,
  Send,
  LocationOn,
  Person,
  LocalShipping,
} from "@mui/icons-material";
import { styled } from "@mui/material/styles";
import contactBanner from "../../assets/image1/contactus.png";

// Reusable styled components
const StyledPaper = styled(Paper)(({ theme }) => ({
  padding: theme.spacing(4),
  borderRadius: theme.spacing(3),
  background: "linear-gradient(145deg, #f8faff, #ffffff)",
  boxShadow: "0 8px 32px rgba(0, 0, 0, 0.1)",
  position: "relative",
  overflow: "hidden",
  "&:before": {
    content: '""',
    position: "absolute",
    top: 0,
    left: 0,
    width: "4px",
    height: "100%",
    background: theme.palette.primary.main,
  },
}));

const SectionTitle = styled(Typography)(({ theme }) => ({
  marginBottom: theme.spacing(3),
  color: theme.palette.primary.dark,
  fontWeight: 700,
  display: "flex",
  alignItems: "center",
  gap: theme.spacing(1),
  "& svg": { fontSize: "1.5rem" },
}));

const StyledButton = styled(Button)(({ theme }) => ({
  borderRadius: theme.spacing(2),
  padding: theme.spacing(2),
  fontSize: "1.1rem",
  transition: "all 0.3s ease",
  background: "linear-gradient(45deg, #1976d2, #2196f3)",
  "&:hover": {
    transform: "translateY(-2px)",
    boxShadow: "0 4px 15px rgba(25, 118, 210, 0.4)",
  },
}));

const ProductBox = styled(Box)(({ theme }) => ({
  marginBottom: theme.spacing(2),
  padding: theme.spacing(3),
  background: "#f8faff",
  borderRadius: theme.spacing(2),
  border: `1px solid ${theme.palette.primary.light}`,
  position: "relative",
}));

const RoundedTextField = styled(TextField)(({ theme }) => ({
  "& .MuiOutlinedInput-root": { borderRadius: theme.spacing(2) },
}));

const AddressSection = ({ title, prefix }) => (
  <>
    <Grid item xs={12}>
      <SectionTitle variant="h6">{title}</SectionTitle>
    </Grid>
    {[
      "First Name",
      "GST No.",
      "Locality/Street",
      "State",
      "City",
      "Pin Code",
    ].map((field, index) => (
      <Grid item xs={12} sm={4} key={field}>
        <RoundedTextField
          fullWidth
          label={field}
          name={`${prefix}_${field.replace(/ /g, "")}`}
          variant="outlined"
        />
      </Grid>
    ))}
  </>
);

const Order = () => {
  const [products, setProducts] = useState([{ id: 1 }]);
  const [stations] = useState(["Station A", "Station B", "Station C"]);

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log("Form submitted!");
  };

  const handleInputChange = (event) => {
    console.log(event.target.name, event.target.value);
  };

  const addProduct = () => {
    setProducts((prev) => [...prev, { id: prev.length + 1 }]);
  };

  const removeProduct = (id) => {
    setProducts((prev) => prev.filter((product) => product.id !== id));
  };

  const renderProductFields = (product, index) => (
    <ProductBox key={product.id}>
      <Grid container spacing={3} alignItems="center">
        <Grid
          item
          xs={12}
          container
          justifyContent="space-between"
          alignItems="center"
        >
          <Typography
            variant="subtitle1"
            color="primary"
            sx={{ fontWeight: 600 }}
          >
            Product #{index + 1}
          </Typography>
          <IconButton
            onClick={() => removeProduct(product.id)}
            disabled={products.length === 1}
            sx={{
              color: products.length === 1 ? "text.disabled" : "error.main",
            }}
          >
            <RemoveCircleOutline />
          </IconButton>
        </Grid>

        {["Receipt No.", "Reference No.", "Insurance"].map((field) => (
          <Grid item xs={12} sm={6} md={3} key={field}>
            <RoundedTextField
              fullWidth
              label={field}
              name={`${field.replace(/ /g, "")}_${product.id}`}
            />
          </Grid>
        ))}

        <Grid item xs={12} sm={6} md={3}>
          <FormControl fullWidth variant="outlined">
            <InputLabel>Payment</InputLabel>
            <Select
              label="Payment"
              name={`payment_${product.id}`}
              sx={{ borderRadius: 2 }}
            >
              <MenuItem value="To Pay">To Pay</MenuItem>
              <MenuItem value="Paid">Paid</MenuItem>
            </Select>
          </FormControl>
        </Grid>

        {["VVP Amount", "Weight Kgs.", "Amount"].map((field) => (
          <Grid item xs={12} sm={4} key={field}>
            <RoundedTextField
              fullWidth
              label={field}
              name={field.replace(/ /g, "")}
            />
          </Grid>
        ))}
      </Grid>
    </ProductBox>
  );

  return (
    <>
      <Box
        sx={{
          mt:5,
          position: "relative",
          width: "100vw",
          height: { xs: "300px", md: "350px" },
          backgroundImage: `url(${contactBanner})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          display: "flex",
          alignItems: "center",
          "&:after": {
            content: '""',
            position: "absolute",
            top: 10,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.6)",
          },
        }}
      >
       <Container 
  sx={{  
    display: "flex", 
    flexDirection: "column",
    justifyContent: "center", 
    alignItems: "center", 
    height: "100vh",
    position: "relative", 
    zIndex: 1 
  }}
>
  <Typography 
    variant="h2"
    sx={{
      color: "white",
      fontWeight: 800,
      fontSize: { xs: "2rem", sm: "3rem", md: "4rem" },
      textShadow: "2px 2px 8px rgba(0,0,0,0.7)",
      textAlign: "center"
    }}
  >
    Make Your Booking
  </Typography>
</Container>

      </Box>

      <Container  maxWidth="lg" sx={{  my: 4, py: 6 }}>
        <StyledPaper>
          <Typography
            variant="h4"
            align="center"
            sx={{
              color: "red",
              fontWeight: 800,
              mb: 6,
              textTransform: "uppercase",
              letterSpacing: 1.2,
            }}
          >
            <LocalShipping
              sx={{ fontSize: "2.5rem", mr: 1.5, verticalAlign: "middle" }}
            />
            Create Your Booking
          </Typography>

          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              {/* Station Section */}
              <Grid item xs={12}>
                <SectionTitle variant="h6">
                  <LocationOn />
                  Station Information
                </SectionTitle>
              </Grid>
              {["Start Station", "Destination Station"].map((label) => (
                <Grid item xs={12} sm={6} key={label}>
                  <FormControl fullWidth variant="outlined">
                    <InputLabel>{label}</InputLabel>
                    <Select
                      label={label}
                      name={label.replace(/ /g, "")}
                      sx={{ borderRadius: 2 }}
                    >
                      {stations.map((station) => (
                        <MenuItem key={station} value={station}>
                          {station}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
              ))}

              {/* Date Fields */}
              {["Booking Date", "Delivery Date"].map((label) => (
                <Grid item xs={12} sm={6} key={label}>
                  <RoundedTextField
                    fullWidth
                    type="date"
                    label={label}
                    name={label.replace(/ /g, "")}
                    InputLabelProps={{ shrink: true }}
                  />
                </Grid>
              ))}

              {/* Customer Section */}
              <Grid item xs={12}>
                <SectionTitle variant="h6">
                  <Person />
                  Customer Information
                </SectionTitle>
              </Grid>
              {["First Name", "Middle Name", "Last Name"].map((field) => (
                <Grid item xs={12} sm={4} key={field}>
                  <RoundedTextField
                    fullWidth
                    label={field}
                    name={field.replace(/ /g, "")}
                  />
                </Grid>
              ))}
              <Grid item xs={12} sm={4}>
                <RoundedTextField
                  fullWidth
                  label="Contact Number"
                  name="ContactNumber"
                />
              </Grid>
              <Grid item xs={12} sm={4}>
                <RoundedTextField
                  fullWidth
                  label="Email Address"
                  name="Email"
                />
              </Grid>

              {/* Address Sections */}
              <AddressSection title="From Address" prefix="from" />
              <AddressSection title="To Address" prefix="to" />

              {/* Product Section */}
              <Grid item xs={12}>
                <SectionTitle variant="h6">
                  <LocalShipping />
                  Product Details
                </SectionTitle>
                {products.map(renderProductFields)}
                <Button
                  variant="outlined"
                  startIcon={<AddCircleOutline />}
                  onClick={addProduct}
                  sx={{
                    mt: 2,
                    borderRadius: 2,
                    borderWidth: 2,
                    "&:hover": { borderWidth: 2 },
                  }}
                >
                  Add Product
                </Button>
              </Grid>

              {/* Additional Fields */}
              <Grid item xs={12}>
                <RoundedTextField
                  fullWidth
                  multiline
                  rows={4}
                  label="Additional Comments"
                  name="additionalComments"
                />
              </Grid>

              {[
                "FREIGHT",
                "INS/VPP",
                "Bill Total",
                "CGST%",
                "SGST%",
                "IGST%",
                "Grand Total",
              ].map((field) => (
                <Grid item xs={12} sm={6} key={field}>
                  <RoundedTextField
                    fullWidth
                    label={field}
                    name={field.replace(/ /g, "")}
                  />
                </Grid>
              ))}

              {/* Submit Button */}
              <Grid item xs={12} sx={{ textAlign: "center" }}>
                <StyledButton
                  type="submit"
                  variant="contained"
                  size="large"
                  startIcon={<Send sx={{ fontSize: "1rem" }} />}
                >
                  Confirm Booking
                </StyledButton>
              </Grid>
            </Grid>
          </form>
        </StyledPaper>
      </Container>
    </>
  );
};

export default Order;
