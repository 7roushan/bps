
import React from "react";
//import AddLocationIcon from '@mui/icons-material/AddLocation';
 export const industryData = [
  {
    
    title: "Agroy Bussiness",
    cod: "We are specialist advisers who provide technical, commercial and financial advice and information to farming, agricultural and public sector staff.",
  },
  {
    title: "Automobile",
    cod: "Our spectrum of staffing expertise are in the fields of Automobiles, Manufacturing, Telecommunication, Power Distribution, etc. and we feel accomplished, when the organizations benefit from our experience.",
  },
  {
    title: "Advertising or Media",
    cod: "We develop strategies for the advertising and marketing needs of our customers. We focuses on the way that businesses communicate with current or prospective clientele and is the person who understands trends.",
  },
  {
    title: "Aviation and Aeroscope",
    cod: 
"We also provide staffing solutions in Aviation and Aerospace thus help them to navigate complexity, address their challenges and achieve their business goals.",
  },
  {
    title: "Banking and Insurance",
    cod: 

"We work across all the major geographies, provides specialized guidance and advice for recruitment in various insurance and banking bodies.",
  },
    {
        title: "Health care",
        cod: "We create and deliver strategies by collaborating with the client to help them to meet their staffing needs in Health care.we feel accomplished, when the organizations benefit from our experience."
    }
];